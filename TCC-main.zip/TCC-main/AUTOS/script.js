// Dropdown menu functionality
document.addEventListener('DOMContentLoaded', () => {
    const dropdownBtn = document.querySelector('.dropdown');
    
    dropdownBtn.addEventListener('mouseover', () => {
        // Adicionar funcionalidade de dropdown se necessário
    });

    // Animação suave para o botão CTA
    const ctaButton = document.querySelector('.cta-button');
    ctaButton.addEventListener('click', () => {
        // Adicionar animação ou redirecionamento
    });

    // Animação de entrada para o mascote
    const mascot = document.querySelector('.mascot');
    mascot.style.opacity = '0';
    
    setTimeout(() => {
        mascot.style.transition = 'opacity 1s ease-in-out';
        mascot.style.opacity = '1';
    }, 500);
});

// Login button functionality
const loginBtn = document.querySelector('.login-btn');
loginBtn.addEventListener('click', () => {
    // Adicionar lógica de login
});

document.addEventListener('DOMContentLoaded', () => {
    const dropdown = document.querySelector('.dropdown');
    const dropdownBtn = document.querySelector('.dropdown-btn');
    const dropdownContent = document.querySelector('.dropdown-content');
    let timeoutId;

    // Função para alternar o dropdown
    function toggleDropdown(event) {
        event.preventDefault();
        event.stopPropagation();
        dropdownContent.classList.toggle('show');
    }

    // Função para mostrar o dropdown
    function showDropdown() {
        clearTimeout(timeoutId);
        dropdownContent.classList.add('show');
    }

    // Função para esconder o dropdown
    function hideDropdown() {
        timeoutId = setTimeout(() => {
            dropdownContent.classList.remove('show');
        }, 200);
    }

    // Event listener para clique no botão
    dropdownBtn.addEventListener('click', toggleDropdown);

    // Event listeners para hover (desktop)
    if (window.innerWidth > 768) {
        dropdown.addEventListener('mouseenter', showDropdown);
        dropdown.addEventListener('mouseleave', hideDropdown);
    }

    // Fechar dropdown quando clicar fora
    document.addEventListener('click', (e) => {
        if (!dropdown.contains(e.target)) {
            dropdownContent.classList.remove('show');
        }
    });

    // Prevenir que o clique nos items do dropdown feche o menu
    dropdownContent.addEventListener('click', (e) => {
        e.stopPropagation();
    });
});


//DE OUTRO SITE
const button = document.getElementById('toggle-theme');
const body = document.body;

// Verifica se o modo escuro está ativado nas preferências do usuário
if (localStorage.getItem('dark-mode') === 'true') {
    body.classList.add('dark-mode');
    
}

// Função para alternar entre os modos
button.addEventListener('click', () => {
    body.classList.toggle('dark-mode');
    const isDarkMode = body.classList.contains('dark-mode');
    localStorage.setItem('dark-mode', isDarkMode);
    
});
// FIM DE OUTRO SITE
