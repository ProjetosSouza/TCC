const button = document.getElementById('toggle-theme');
const body = document.body;

// Verifica se o modo escuro está ativado nas preferências do usuário
if (localStorage.getItem('dark-mode') === 'true') {
    body.classList.add('dark-mode');
    
}

// Função para alternar entre os modos
button.addEventListener('click', () => {
    body.classList.toggle('dark-mode');
    const isDarkMode = body.classList.contains('dark-mode');
    localStorage.setItem('dark-mode', isDarkMode);
    
});
